<?php
/**
 * Buddypress Wall Template Tags
 *
 * @package BP-Wall
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/*
add_action("bp_before_member_activity_post_form","bp_wall_before_member_activity_post_form");

function bp_wall_before_member_activity_post_form(){
	if ( is_user_logged_in() && !bp_current_action() || bp_is_current_action( 'just-me' ) )    
		locate_template( array( 'activity/post-form.php'), true );

}
*/
