<?php
/**
 * BP Suggest Widgets 
 *  
 * @package BP-Wall
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;