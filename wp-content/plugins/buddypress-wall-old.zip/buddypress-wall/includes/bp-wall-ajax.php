<?php
/**
 * BP Wall ajax
 *
 * @package BP-Wall
 */
 
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;