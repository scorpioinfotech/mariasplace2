<?php get_header(); ?>

<?php require('post-loop.php'); ?>
					
<?php get_footer(); ?>