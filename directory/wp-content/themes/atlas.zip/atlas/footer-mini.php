<?php
/**
 * The template for displaying the footer for the homepage.
 *
 * @package Atlas
 */

?>

<?php wp_footer(); ?>
</body>
</html>