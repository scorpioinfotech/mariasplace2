<?php
/**
 * Module Name: Hangar - Theme Widgets
 * Module Description: This module loads additional widgets support by ThemesDepot Themes.
 * Module Version: 1.0.0
 *
 * @package Hangar
 * @subpackage Bundled
 * @since 1.0.0
 */
 
if ( ! empty( $_SERVER['SCRIPT_FILENAME'] ) && basename( __FILE__ ) == basename( $_SERVER['SCRIPT_FILENAME'] ) ) {
    die ( 'Please do not load this screen directly. Thanks!' );
}
 
/**
 * Check if the theme supports the following widgets and then loads them.
 */
require_once( 'classes/widgets-class.php' );

function hangar_load_widgets_files(){

  require_once( 'widgets/widget-subscribe.php' );
  require_once( 'widgets/widget-listings-details.php' );
  require_once( 'widgets/widget-contact-form.php' );
  require_once( 'widgets/widget-listing-map.php' );
  require_once( 'widgets/widget-listings-categories.php' );
  require_once( 'widgets/widget-listings-location.php' );
  require_once( 'widgets/widget-featured-author.php' );
  require_once( 'widgets/widget-latest-listings.php' );
  require_once( 'widgets/widget-featured-listings.php' );
  require_once( 'widgets/widget-listings-search.php' );
  require_once( 'widgets/widget-listings-profile.php' );
  require_once( 'widgets/widget-listings-tags.php' );
  require_once( 'widgets/widget-current-listing-tags.php' );
  require_once( 'widgets/widget-listings-child-categories.php' );

}
add_action( 'after_setup_theme', 'hangar_load_widgets_files');

// Register widget
if ( ! function_exists( 'hangar_register_theme_widget' ) ) {
    
  function hangar_register_theme_widget() {
    
      register_widget( 'Hangar_Subscribe_Widget' );
      register_widget( 'TDP_Listings_Details' );
      register_widget( 'TDP_Listings_Contact' );
      register_widget( 'TDP_Listings_Map' );
      register_widget( 'TDP_Listings_Categories' );
      register_widget( 'TDP_Listings_Locations' );
      register_widget( 'TDP_Featured_Author' );
      register_widget( 'TDP_Latest_Listings' );
      register_widget( 'TDP_Featured_Listings' );
      register_widget( 'TDP_Listings_Search' );
      register_widget( 'TDP_Listings_Profile' );
      register_widget( 'TDP_Listings_Tags' );
      register_widget( 'TDP_Listings_Current_Tags' );
      register_widget( 'TDP_Listings_Child_Categories' );
    
  }

  add_action( 'widgets_init', 'hangar_register_theme_widget', 1 );
  
}

?>