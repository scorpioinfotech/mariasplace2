<?php
/**
 * Raised when a client library must be upgraded.
 *
 * @package    Braintree
 * @subpackage Exception
 * @copyright  2010 Braintree Payment Solutions
 */
class Braintree_Exception_UpgradeRequired extends Braintree_Exception
{

}
