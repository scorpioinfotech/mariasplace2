jQuery(document).ready(function() {
		"use strict";

		jQuery('ul.sf-menu').superfish({
			delay:       1000,                            // one second delay on mouseout
			animation:   {opacity:'show',height:'show'},  // fade-in and slide-down animation
			speed:       'fast',                          // faster animation speed
			autoArrows:  false                            // disable generation of arrow mark-up
		});
		
        jQuery('.flexslider').flexslider({
        
                prevText: "<span class='icon-angle-left'></span>",           //String: Set the text for the "previous" directionNav item
                nextText: "<span class='icon-angle-right'></span>", 
        
        });

        jQuery('input[type=button].add-image').addClass('button small black');

        jQuery(".type_list div.one_third:nth-child(3n)").addClass("last");

		jQuery(".wrapper").fitVids();

        jQuery('.follow-link a, #mail-submit').addClass('dp-button medium no-shadow');

		jQuery('.latest-blog .blog-item:last-child').addClass('last');

        jQuery('.mfp-img').addClass('animated flipInX');

        jQuery('.widget_categories ul li').hover(
            function () {
                //alert("asa");
                //show its submenu
                //var isVisible = $(this).next('ui').is(':visible');
                //alert("dvData is " + isVisible);
                //var isHidden = $(this).next('ui').is(':hidden');
               // alert("dvData is " + isHidden);

                jQuery(this).children('ul').css({display: "block"}).fadeIn('slow');

            }, 
            function () {
                //hide its submenu
                jQuery(this).children('ul').css({display: "none"}).fadeOut('slow');
            }
        );

        jQuery('#open-search, #open-claim').magnificPopup({
            type:'inline',
            src: '#search-popup', // CSS selector of an element on page that should be used as a popup
            midClick: true,
            callbacks: {
                open: function() {

                    jQuery('#wpas-tax_listings_categories').append('<div id="status_loader"></div>');
                    jQuery('#wpas-tax_listings_location').append('<div id="status_loader2"></div>');

                  // Will fire when this exact popup is opened
                  // this - is Magnific Popup object
                    /* 
                    * Ajax Request to get cats
                    */
                    jQuery(function(){
                        jQuery('#main_cat').change(function(){
                            jQuery('#status_loader').show();
                            var jQuerymainCat=jQuery('#main_cat').val();
                            // call ajax
                            jQuery("#tax_listings_categories").empty();
                                jQuery.ajax({
                                    url:popup_url+"/wp-admin/admin-ajax.php",     
                                    type:'POST',
                                    data:'action=tdp_search_ajax_call&main_catid=' + jQuerymainCat,
                                    success:function(results) {
                                    //  alert(results);
                                    jQuery('#status_loader').hide();

                                    jQuery('#tax_listings_categories')
                                        .find('option')
                                        .remove()
                                        .end()
                                    ;

                                    jQuery("#tax_listings_categories").removeAttr("disabled");        
                                            jQuery("#tax_listings_categories").append(results);
                                    }
                                });
                            }
                        );
                    });

                    /* 
                    * Ajax Request to get cats
                    */
                    jQuery(function(){
                        jQuery('#main_loc').change(function(){
                            jQuery('#status_loader2').show();
                            var jQuerymainLoc=jQuery('#main_loc').val();
                            // call ajax
                            jQuery("#tax_listings_location").empty();
                                jQuery.ajax({
                                    url: popup_url+"/wp-admin/admin-ajax.php",     
                                    type:'POST',
                                    data:'action=tdp_search_ajax_call2&main_catid2=' + jQuerymainLoc,
                                    success:function(results) {
                                    //  alert(results);
                                    jQuery('#status_loader2').hide();

                                    jQuery('#tax_listings_location')
                                        .find('option')
                                        .remove()
                                        .end()
                                    ;

                                    jQuery("#tax_listings_location").removeAttr("disabled");        
                                            jQuery("#tax_listings_location").append(results);
                                    }
                                });
                            }
                        );
                    });

                },
                close: function() {
                  // Will fire when popup is closed
                }
                // e.t.c.
            }
        });

        jQuery('.gallery').each(function() { // the containers for all your galleries should have the class gallery
            jQuery(this).magnificPopup({
                delegate: 'a', // the container for each your gallery items
                type: 'image',
                gallery:{enabled:true}
            });
        }); 

        jQuery('.slides').each(function() { // the containers for all your galleries should have the class gallery
            jQuery(this).magnificPopup({
                delegate: 'a', // the container for each your gallery items
                type: 'image',
                gallery:{enabled:true},
                removalDelay: 500, //delay removal by X to allow out-animation
                  callbacks: {
                    beforeOpen: function() {
                      // just a hack that adds mfp-anim class to markup 
                       this.st.image.markup = this.st.image.markup.replace('mfp-figure', 'mfp-figure animated bounceInDown');
                       //this.st.mainClass = this.st.el.attr('data-effect');
                    }

                  },
                  closeOnContentClick: true,
            });
        });

                jQuery('#wpas-tax_listings_categories').append('<div id="status_loader"></div>');
                jQuery('#wpas-tax_listings_location').append('<div id="status_loader2"></div>');

                jQuery("#contactform, #fcontactform").validate();

                jQuery("#submitform").validate();
                
                jQuery('#wp-advanced-search input, #side-navigation input, #front-login input, #routeForm input').iCheck({
                    checkboxClass: 'icheckbox_square-blue',
                    radioClass: 'iradio_square-blue',
                    increaseArea: '20%' // optional
                  });
                
                jQuery('#content-container .acf-tab-group').append('<div class="submit-border"></div>');

                jQuery('#wpas-tax_post_tag').after('<div class="clear"></div>');

                jQuery("a#fav-nonlogged").click(function() {
                    jQuery('#fav-logged-message').show("scale", 500);
                });
            
                jQuery(function() {
                    jQuery( "#side-navigation" ).tabs();
                });

                //  Responsive layout, resizing the items
                jQuery('#foo4').carouFredSel({
                    responsive: true,
                    width: '100%',
                    scroll: 1,
                    items: {
                        width: 400,
                    //  height: '30%',  //  optionally resize item-height
                        visible: {
                            min: 4,
                            max: 20
                        }
                    }
                });

                jQuery('#listing_gallery').carouFredSel({
                    responsive: true,
                    width: '100%',
                    scroll: 1,
                    items: {
                        width: 400,
                    //  height: '30%',  //  optionally resize item-height
                        visible: {
                            min: 3,
                            max: 20
                        }
                    }
                });



    //Scroll Animation
    /*---------------------------------------------------------------------------------------------*/

    
    /*--------------------------------------------------------------------*/
    //CSS Animation function
    /*--------------------------------------------------------------------*/
    var performAnimFunc = function(mainContentAnim,hideFields,delayAnim,timeOut){
        var hiddenClass = 'visibility-hidden';
        $(hideFields,$(mainContentAnim)).addClass(hiddenClass);
        var contentAnim = function(){
            $(mainContentAnim).each(function(index, element) {
                var $el = $(this);
                var animRandomization = $el.data('randomization');
                var offsetTop = $el.offset().top;
                if(offsetTop-500 < $(window).scrollTop()){
                    if($el.hasClass('fired')) return;
                    
                    
    
                    var hideFieldsTotal = $(hideFields,this).length;
                    $(hideFields,this).each(function(indexChild, elementChild) {
                        var $elChild = $(this);
                        var animClass = 'animated '+ $elChild.data('animation');
                        //console.log(animClass);
                        
                        var dataChild = $(this).data('child');
                        if (typeof dataChild !== 'undefined' && dataChild !== false)
                        {
                            var subChild = dataChild;
                            
                            $elChild.find(subChild).addClass(hiddenClass);
                            $elChild.removeClass(hiddenClass);
                            $(subChild, this).each(function(indexSubChild, elementSubChild) {
                                var $elSubChild = $(this);
                                
                                var delayTime = animRandomization === true ? Math.floor(Math.random() * (timeOut*3)) : indexSubChild * timeOut/2;
                                setTimeout( function() {
                                    $elSubChild.removeClass(hiddenClass).addClass(animClass);
                                    //Remove the class after done animation
                                    setTimeout( function() {$elSubChild.removeClass(animClass)},timeOut*10);
                                }, (indexSubChild !== 0 ? delayTime : 0 ));
                                //}, (indexSubChild !== 0 ? indexSubChild * timeOut/2 : 0 ));
                            });
                            $el.addClass('fired');
                        }else{
                            
                            var delayTime = animRandomization === true ? Math.floor(Math.random() * (timeOut*3)) : indexChild * timeOut;
                            setTimeout( function() {
                                $elChild.removeClass(hiddenClass).addClass(animClass);
                                
                                if(indexChild == 0){
                                    $el.addClass('fired');  
                                }
                                //$el.addClass('fired');
                                $el.addClass('index-'+ index);
                                $elChild.addClass('temp-'+ indexChild * delayAnim);
                                //Remove the class after done animation
                                setTimeout( function() {$elChild.removeClass(animClass)},timeOut*10);
                            //}, (indexChild !== 0 ? indexChild * timeOut : 0 ));   
                            }, (indexChild !== 0 ? delayTime : 0 ));    
                            
                        }
                    });
                }
            }); 
        };
        $(window).on('load',function(){
            contentAnim();
        });
        
        var scrollTrigger = false;
        $(window).scroll(function(){
            scrollTrigger = true;
        });
        
        var interval, intervalClearer;  
        
        interval = setInterval(function() {
            if ( scrollTrigger ) {
                scrollTrigger = false;
                contentAnim();
            }
        },250);
        
        intervalClearer = setInterval(function() {
            var sectionLength = $('.mds-page-section.animatiton-enabled:not(.fired)').length;
            if(sectionLength){
                //console.log('Unfired: ' + sectionLength);
            }
            else{
                clearInterval(interval);
                clearInterval(intervalClearer);
                //console.log('Interval cleared');
            }
        },500);
        
        
    };
    
    /*--------------------------------------------------------------------*/
    //Parallax Performance function
    /*--------------------------------------------------------------------*/
    var parallaxAnimFunc = function(){
        var scrollTrigger = false, yPos, coords;
        
        $(window).scroll(function(){
            scrollTrigger = true;
        });
        
        setInterval(function() {
            if ( scrollTrigger ) {
                
                scrollTrigger = false;
                $('section.mds-page-section[data-parallax]').each(function(index, element){
                    var $el = $(this); 
                    
                    //console.log($el.scrollTop());
                    
                    var elOffsetTop = $el.offset().top,
                        windowHeight = $(window).height(),
                        windowScrollTop = $(window).scrollTop();
                    
                    //only move the background when the section is in the viewport
                    if(elOffsetTop - windowHeight < windowScrollTop && elOffsetTop + windowHeight > windowScrollTop ){
                        // Put together our final background position
                        
                        /*if(index == 1 ){
                            console.log(windowScrollTop - (elOffsetTop - windowHeight));    
                        }*/
                        
                        var sectionOnViewport = windowScrollTop - (elOffsetTop - windowHeight);
                        yPos = -(sectionOnViewport / parseInt($el.data('parallax')) );
                        /*sectionOnViewport = windowScrollTop - elOffsetTop;
                        yPos = ((sectionOnViewport / parseInt($el.data('parallax')) - $el.height()/2) );*/
                        coords = '50% '+ yPos + 'px';
                        
                        // Move the background
                        $el.css({ backgroundPosition: coords });
                        
                    }
                });
            }
        },50);
    }
    /*var parallaxMousemoveFunc = function(el){ 
        
        el.on('mousemove', function(e){
            
            var mouse_dx = - e.pageX - ($(window).width() / 2);
            var mouse_dy = - (e.pageY - el.offset().top) - (el.outerHeight() / 2);
            el.css({
                backgroundPosition : mouse_dx + 'px ' + mouse_dy + 'px'
            });
        });
    };*/
    
});

jQuery(window).bind("load resize", function(){
            var windowWidth = jQuery(window).width();
            var RowWidth = jQuery("body").find(".span12").eq(1).width();

            /**
             * Out of the box content blocks functionality
             */

            var outoftheboxMargin = "-"+(windowWidth-RowWidth)/2+"px";

            if ( !jQuery(".sidebar-enabled")[0] ) { // do nothing if sidebar enabled (element with .sidebar-enabled exists)
                jQuery(".out-box").each(function() {
                    jQuery(this).css({"margin-left":outoftheboxMargin,"margin-right":outoftheboxMargin});
                });
            }


    });