<?php
/*
Template Name: Homepage With Map And Custom Content
 * @package Atlas
 */

get_header();

$sidebar_position = get_field('inner_page_layout');

?>

<section id="header-map" class="slidingDiv">

	<div id="map"></div>

	<?php get_template_part( 'includes/map', 'loader' );?>

</section>

<div class="clear"></div>

<section id="page-wrapper">

	<div id="page-content" class="wrapper">

		<?php if($sidebar_position == 'Sidebar Left') { ?>

			<div class="one_third" id="sidebar-wrapper">
				<?php dynamic_sidebar( 'Page Sidebar' ); ?>
			</div>

		<?php } ?>


		<div id="content-container" class="<?php if($sidebar_position == 'Sidebar Left') { echo 'two_third last'; } else if($sidebar_position == 'Sidebar Right') { echo 'two_third'; } ?>">

			<?php if ( have_posts() ) : ?>

				<?php while ( have_posts() ) : the_post(); ?>

					<article <?php post_class();?>>

						<?php get_template_part( 'content', 'page' ); ?>

					</article>

				<?php endwhile; ?>

			<?php else : ?>

				<?php get_template_part( 'no-results', 'index' ); ?>

			<?php endif; ?>

		</div>

		<?php if($sidebar_position == 'Sidebar Right'  ) { ?>

			<div class="one_third last" id="sidebar-wrapper">
				<?php dynamic_sidebar( 'Page Sidebar' ); ?>
			</div>

		<?php } ?>

		<div class="clearboth"></div>

	</div>

</section>

<?php get_footer();?>