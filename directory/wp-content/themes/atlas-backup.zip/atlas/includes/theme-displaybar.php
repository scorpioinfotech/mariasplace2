<section id="display-bar">

	<div class="wrapper">

		<div class="three_fourth" id="smart-breadcrumb">
			<?php if (function_exists('tdp_breadcrumbs')) tdp_breadcrumbs(); ?>
		</div>

		<div class="one_fourth last" id="layout-changer">
			
			<a href="<?php echo add_query_arg( 'listview', 'grid' );?>"><span class="icon-th"></span><?php _e('Grid View','atlas');?></a>
			<a href="<?php echo add_query_arg( 'listview', 'list' );?>"><span class="icon-th-list"></span><?php _e('List View','atlas');?></a>

		</div>	

		<div class="clear"></div>

	</div>

</section>