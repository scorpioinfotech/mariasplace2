<section id="breadcrumb">

	<div class="wrapper">
		
		<div class="one_half">
	
			<?php _e('Search Results','atlas');?>
	
		</div>

		<div class="one_half last">
		</div>

		<div class="clearboth"></div>

	</div>

</section>